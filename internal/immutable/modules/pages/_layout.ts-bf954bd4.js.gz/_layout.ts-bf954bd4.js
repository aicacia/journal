import{p as e,s as p}from"../../chunks/_layout-7e4796dc.js";export{e as prerender,p as ssr};
