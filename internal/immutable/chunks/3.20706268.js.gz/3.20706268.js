import{default as t}from"../entry/privacy-policy-page.svelte.3e3f0fb5.js";export{t as component};
