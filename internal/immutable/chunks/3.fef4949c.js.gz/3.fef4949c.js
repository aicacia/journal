import{default as t}from"../entry/privacy-policy-page.svelte.cbcb390f.js";export{t as component};
