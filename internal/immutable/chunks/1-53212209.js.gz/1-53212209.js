import{default as m}from"../components/error.svelte-d93080df.js";import"./index-01b389ab.js";export{m as component};
