import{_ as r}from"./_layout.7e4796dc.js";import{default as t}from"../entry/_layout.svelte.a2ba94ab.js";export{t as component,r as universal};
