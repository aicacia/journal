import{default as t}from"../entry/privacy-policy-page.svelte.9f23e129.js";export{t as component};
