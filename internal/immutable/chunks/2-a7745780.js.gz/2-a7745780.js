import{default as t}from"../components/pages/_page.svelte-2e37a577.js";export{t as component};
