import{default as t}from"../entry/privacy-policy-page.svelte.5f3d1794.js";export{t as component};
