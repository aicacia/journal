import{default as t}from"../components/error.svelte-7f83478b.js";export{t as component};
