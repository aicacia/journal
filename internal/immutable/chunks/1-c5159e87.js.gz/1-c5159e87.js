import{default as t}from"../components/error.svelte-cd1484f1.js";export{t as component};
