import{default as t}from"../components/pages/_page.svelte-13f11adc.js";export{t as component};
