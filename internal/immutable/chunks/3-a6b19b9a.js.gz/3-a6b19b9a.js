import{default as t}from"../components/pages/privacy-policy/_page.svelte-3a460c0d.js";export{t as component};
