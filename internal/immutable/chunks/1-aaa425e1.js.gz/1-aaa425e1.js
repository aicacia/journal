import{default as t}from"../components/error.svelte-57fb662b.js";export{t as component};
