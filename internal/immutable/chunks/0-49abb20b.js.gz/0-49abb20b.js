import{_ as r}from"./_layout-c2405b24.js";import{default as t}from"../components/pages/_layout.svelte-3dd86b41.js";export{t as component,r as shared};
