import{default as t}from"../entry/privacy-policy-page.svelte.d6c145b9.js";export{t as component};
