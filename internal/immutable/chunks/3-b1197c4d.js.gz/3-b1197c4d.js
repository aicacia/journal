import{default as t}from"../components/pages/privacy-policy/_page.svelte-fcdd55a4.js";export{t as component};
