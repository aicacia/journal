import{default as m}from"../components/pages/_layout.svelte-d7f550d8.js";import"./index-d280f66e.js";export{m as component};
