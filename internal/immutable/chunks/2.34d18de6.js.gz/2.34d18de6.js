import{default as t}from"../entry/_page.svelte.4adbdf44.js";export{t as component};
