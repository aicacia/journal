import{default as t}from"../components/pages/_page.svelte-fe23889f.js";export{t as component};
