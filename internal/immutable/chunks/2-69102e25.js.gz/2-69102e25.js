import{default as t}from"../components/pages/_page.svelte-6b3a7abe.js";export{t as component};
