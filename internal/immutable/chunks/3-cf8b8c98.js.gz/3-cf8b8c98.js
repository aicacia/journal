import{default as t}from"../components/pages/privacy-policy/_page.svelte-f997c350.js";export{t as component};
