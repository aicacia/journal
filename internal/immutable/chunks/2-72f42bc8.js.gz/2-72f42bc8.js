import{default as t}from"../components/pages/_page.svelte-3baa0391.js";export{t as component};
