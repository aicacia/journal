import{default as m}from"../components/pages/_layout.svelte-6bb0572b.js";import"./index-01b389ab.js";export{m as component};
