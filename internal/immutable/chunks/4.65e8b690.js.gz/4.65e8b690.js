import{default as t}from"../entry/terms-of-service-page.svelte.a0e8fbce.js";export{t as component};
