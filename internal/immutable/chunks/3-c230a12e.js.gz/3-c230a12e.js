import{default as t}from"../components/pages/privacy-policy/_page.svelte-967223a1.js";export{t as component};
