import{default as t}from"../components/pages/_page.svelte-61027c2d.js";export{t as component};
