import{default as t}from"../components/pages/_page.svelte-29fe1781.js";export{t as component};
