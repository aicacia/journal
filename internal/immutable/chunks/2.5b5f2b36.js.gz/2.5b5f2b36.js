import{default as t}from"../entry/_page.svelte.932082bb.js";export{t as component};
