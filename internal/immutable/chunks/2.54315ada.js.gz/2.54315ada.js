import{default as t}from"../entry/_page.svelte.34704c49.js";export{t as component};
