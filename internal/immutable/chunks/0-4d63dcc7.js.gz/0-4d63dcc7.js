import{default as t}from"../components/pages/_layout.svelte-449af929.js";export{t as component};
