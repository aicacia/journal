import{default as t}from"../components/pages/privacy-policy/_page.svelte-8239d1f1.js";export{t as component};
