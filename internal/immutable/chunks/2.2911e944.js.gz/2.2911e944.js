import{default as t}from"../entry/_page.svelte.92b9afd4.js";export{t as component};
