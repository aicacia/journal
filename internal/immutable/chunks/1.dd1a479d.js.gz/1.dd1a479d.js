import{default as t}from"../entry/error.svelte.75363861.js";export{t as component};
