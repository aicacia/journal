import{default as t}from"../entry/privacy-policy-page.svelte.bc60ef2a.js";export{t as component};
