import{default as t}from"../entry/_page.svelte.547881d3.js";export{t as component};
