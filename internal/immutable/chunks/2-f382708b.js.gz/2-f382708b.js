import{default as t}from"../components/pages/_page.svelte-a41d3311.js";export{t as component};
