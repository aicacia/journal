import{default as t}from"../components/pages/_page.svelte-e529e75d.js";export{t as component};
