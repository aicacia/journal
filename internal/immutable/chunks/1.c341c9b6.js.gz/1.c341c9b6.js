import{default as t}from"../entry/error.svelte.807a9784.js";export{t as component};
