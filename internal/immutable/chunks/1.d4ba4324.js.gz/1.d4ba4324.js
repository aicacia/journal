import{default as t}from"../entry/error.svelte.c9599346.js";export{t as component};
