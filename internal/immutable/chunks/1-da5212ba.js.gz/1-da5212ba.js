import{default as t}from"../components/error.svelte-e76ba16c.js";export{t as component};
