import{default as t}from"../entry/error.svelte.a1a0c6b2.js";export{t as component};
