import{default as t}from"../components/error.svelte-5cfbee3c.js";export{t as component};
