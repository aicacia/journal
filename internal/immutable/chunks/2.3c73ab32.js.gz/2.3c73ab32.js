import{default as t}from"../entry/_page.svelte.4665a560.js";export{t as component};
