import{default as t}from"../components/pages/terms-of-service/_page.svelte-001c3990.js";export{t as component};
