import{default as e}from"../components/error.svelte-1b8bf8a3.js";import"./index-d280f66e.js";import"./singletons-cacf17a9.js";import"./paths-e96a59cd.js";export{e as component};
