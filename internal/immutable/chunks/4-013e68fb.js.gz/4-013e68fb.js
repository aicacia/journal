import{default as t}from"../components/pages/terms-of-service/_page.svelte-a1055ee8.js";export{t as component};
