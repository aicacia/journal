import{default as t}from"../components/pages/_page.svelte-ad1e3610.js";export{t as component};
