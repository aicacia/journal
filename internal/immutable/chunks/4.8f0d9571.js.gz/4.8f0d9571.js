import{default as t}from"../entry/terms-of-service-page.svelte.f52bac9e.js";export{t as component};
