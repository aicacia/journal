import{default as t}from"../entry/terms-of-service-page.svelte.4e875592.js";export{t as component};
