import{default as t}from"../components/pages/terms-of-service/_page.svelte-f26a21f0.js";export{t as component};
