import{default as t}from"../entry/error.svelte.7b104c48.js";export{t as component};
