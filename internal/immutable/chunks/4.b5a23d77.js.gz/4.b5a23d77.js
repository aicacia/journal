import{default as t}from"../entry/terms-of-service-page.svelte.7ed0e6cf.js";export{t as component};
