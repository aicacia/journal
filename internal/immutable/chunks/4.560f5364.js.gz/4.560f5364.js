import{default as t}from"../entry/terms-of-service-page.svelte.48479dde.js";export{t as component};
