import{default as t}from"../entry/terms-of-service-page.svelte.1e6804a8.js";export{t as component};
