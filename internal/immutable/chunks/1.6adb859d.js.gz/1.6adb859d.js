import{default as t}from"../entry/error.svelte.2857e591.js";export{t as component};
