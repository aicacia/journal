import{default as t}from"../components/pages/terms-of-service/_page.svelte-5de1256d.js";export{t as component};
